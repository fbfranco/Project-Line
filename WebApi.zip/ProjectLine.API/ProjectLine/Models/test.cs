﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProjectLine.Models
{
    public class test
    {
        //test control version
    }
}